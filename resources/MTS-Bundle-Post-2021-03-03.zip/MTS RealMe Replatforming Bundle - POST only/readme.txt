================================================================================
   MTS Resources
================================================================================

========================
A. Keys and Certificates
========================
This site requires the use of the following pre-configured keys and certificates:

  1. A Service Provider SAML signing private key. Used to sign SAML requests to
     the MTS IdP. The associated Service Provider signing certificate will be
     held on the MTS SAML IdP to validate signatures.

  2. An MTS IdP SAML signing certificate for the Login MTS and an MTS IdP signing
     certificate for the assert MTS. Used to check signatures in MTS IdP
     SAML responses.

The certificates are in Internet RFC 1421 standard, also known as Base 64 encoding.
These are :
  mts_login_saml_idp.cer       (for [2] )
  mts_assert_saml_idp.cer      (for [2] )


The private keys are in pkcs#8 (pem) format. These files are:
  mts_saml_sp.pem           (for [1] )


The public keys are in Internet RFC 1421 standard, also known as Base 64 encoding.
These are :
  mts_saml_sp.cer           (for [1] )


The private keys are also supplied in  pkcs#12 (p12) format. These files are:
  mts_saml_sp.p12           (for [1] )

The password to the p12 files are 'password'

========================
B. MTS IdP SAML Metadata
========================
2 MTS IdP SAML2 metadata files are also published to aid your SP SAML product
integration with the MTS.

This is contained in the files : 
  Realme_IDP_Metadata_LoginService.xml     (for login service integration)
  Realme_IDP_Metadata_AssertionService.xml (for assertion service integration)

Note that these files also contain the MTS IdP SAML signing certificates which is
the same as contained in mts_login_saml_idp.cer and mts_assert_saml_idp.cer.

========================
C. SAML SP Metadata
========================
One sample SP SAML2 metadata file is also published to aid your integration with
the MTS:

  MTSSP_PostBinding_Sample.xml 

Note the filealso contains the expected SP SAML signing certificate.
This is the certificate for the provided Service Provider SAML signing key-pair
as contained in mts_saml_sp.p12.
